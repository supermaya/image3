<?php
// 모든 PHP 파일의 맨 위에 세션을 시작합니다.
session_start();

header('Content-Type: application/json');
include 'db_config.php'; // 데이터베이스 연결 설정 파일을 포함합니다.

// 데이터베이스 연결 오류를 확인하고 즉시 종료
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "데이터베이스 연결 실패: " . $conn->connect_error]);
    exit();
}

// 클라이언트로부터 전송된 JSON 데이터를 디코딩합니다. (FormData가 아닌 JSON 요청의 경우)
$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? ''; // JSON 요청에서 액션을 가져옵니다.

// 파일 업로드 요청의 경우 FormData를 사용하므로 $_POST에서 action을 가져옵니다.
if (empty($action) && isset($_POST['action'])) {
    $action = $_POST['action'];
}

switch ($action) {
    case 'signup':
        // 사용자 회원가입 처리
        $email = $conn->real_escape_string($input['email']);
        $password = $input['password'];
        $role = $conn->real_escape_string($input['role']); // user 또는 creator

        if (empty($email) || empty($password)) {
            echo json_encode(["success" => false, "message" => "이메일과 비밀번호를 입력해주세요."]);
            break;
        }

        // 비밀번호를 안전하게 해싱합니다.
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // 사용자 정보를 데이터베이스에 삽입합니다.
        // users 테이블에 role 컬럼이 추가되어야 합니다.
        $stmt = $conn->prepare("INSERT INTO users (email, password, role) VALUES (?, ?, ?)");

        if (!$stmt) {
            echo json_encode(["success" => false, "message" => "SQL 준비 실패: " . $conn->error]);
            break;
        }

        $stmt->bind_param("sss", $email, $hashed_password, $role);

        if ($stmt->execute()) {
            // 회원가입 성공 후 바로 로그인 세션 설정
            $_SESSION['loggedin'] = true;
            $_SESSION['user_id'] = $conn->insert_id; // 새로 생성된 user의 ID 저장
            $_SESSION['username'] = $email; // 이메일을 username으로 사용
            $_SESSION['user_role'] = $role;
            echo json_encode(["success" => true, "message" => "회원가입 성공", "username" => $email, "userRole" => $role]);
        } else {
            echo json_encode(["success" => false, "message" => "회원가입 실패: " . $stmt->error]);
        }
        $stmt->close();
        break;

    case 'login':
        // 사용자 로그인 처리
        $email = $conn->real_escape_string($input['email']);
        $password = $conn->real_escape_string($input['password']);

        if (empty($email) || empty($password)) {
            echo json_encode(["success" => false, "message" => "이메일과 비밀번호를 입력해주세요."]);
            break;
        }

        // 데이터베이스에서 사용자 정보를 조회합니다.
        // role 컬럼도 함께 조회합니다.
        $stmt = $conn->prepare("SELECT id, email, password, role FROM users WHERE email = ?");

        if (!$stmt) {
            echo json_encode(["success" => false, "message" => "SQL 준비 실패: " . $conn->error]);
            break;
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            // 저장된 해시 비밀번호와 입력된 비밀번호를 비교합니다.
            if (password_verify($password, $user['password'])) {
                $_SESSION['loggedin'] = true;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];
                echo json_encode(["success" => true, "message" => "로그인 성공", "username" => $user['email'], "userRole" => $user['role']]);
            } else {
                echo json_encode(["success" => false, "message" => "비밀번호가 올바르지 않습니다."]);
            }
        } else {
            echo json_encode(["success" => false, "message" => "존재하지 않는 이메일입니다."]);
        }
        $stmt->close();
        break;

    case 'googleLogin':
        // Google 로그인 처리 (회원가입 및 로그인)
        $email = $conn->real_escape_string($input['email']);
        $name = $conn->real_escape_string($input['name']);

        // Google 로그인 사용자는 항상 'user' (일반 회원) 역할로 설정합니다.
        $role = 'user';

        // 1. 이미 존재하는 이메일인지 확인
        $stmt = $conn->prepare("SELECT id, email, role FROM users WHERE email = ?");
        if (!$stmt) {
            echo json_encode(["success" => false, "message" => "SQL 준비 실패: " . $conn->error]);
            exit();
        }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // 2-1. 존재하는 사용자: 로그인 처리
            $user = $result->fetch_assoc();
            $_SESSION['loggedin'] = true;
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            echo json_encode(["success" => true, "message" => "Google 로그인 성공", "username" => $user['email'], "userRole" => $user['role']]);
        } else {
            // 2-2. 새로운 사용자: 회원가입 처리
            // Google 로그인 사용자는 비밀번호가 필요 없으므로 빈 문자열로 저장합니다.
            // 회원 기록은 users DB 테이블에 저장됩니다.
            $google_password_placeholder = '';
            $stmt_insert = $conn->prepare("INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)");
            if (!$stmt_insert) {
                echo json_encode(["success" => false, "message" => "SQL 준비 실패: " . $conn->error]);
                exit();
            }
            $stmt_insert->bind_param("ssss", $email, $google_password_placeholder, $name, $role);

            if ($stmt_insert->execute()) {
                $_SESSION['loggedin'] = true;
                $_SESSION['user_id'] = $conn->insert_id;
                $_SESSION['username'] = $email;
                $_SESSION['user_role'] = $role;
                echo json_encode(["success" => true, "message" => "Google 계정으로 회원가입 및 로그인 성공", "username" => $email, "userRole" => $role]);
            } else {
                echo json_encode(["success" => false, "message" => "Google 회원가입 실패: " . $stmt_insert->error]);
            }
            $stmt_insert->close();
        }
        $stmt->close();
        break;

    case 'logout':
        session_unset();
        session_destroy();
        echo json_encode(["success" => true, "message" => "로그아웃 성공"]);
        break;

    case 'checkLoginStatus':
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
            $user_role = $_SESSION['user_role'] ?? 'user';
            echo json_encode(["success" => true, "username" => $_SESSION['username'], "userRole" => $user_role]);
        } else {
            echo json_encode(["success" => false, "message" => "로그인되지 않았습니다."]);
        }
        break;

    case 'uploadFile':
        // 'creator' 역할 사용자만 업로드 가능
        if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || ($_SESSION['user_role'] ?? 'user') !== 'creator') {
            echo json_encode(["success" => false, "message" => "크리에이터만 파일을 업로드할 수 있습니다."]);
            exit();
        }

        $fileType = $_POST['fileType'] ?? '';
        $urls = [];
        $uploadDir = __DIR__ . '/uploads/';

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        if ($fileType === 'audio' && isset($_FILES['audioFile'])) {
            $file = $_FILES['audioFile'];
            if ($file['error'] === UPLOAD_ERR_OK) {
                $targetSubDir = 'audio/';
                $targetPath = $uploadDir . $targetSubDir;
                if (!is_dir($targetPath)) {
                    mkdir($targetPath, 0777, true);
                }
                $file_name = basename($file['name']);
                $new_file_name = uniqid() . '_' . $file_name;
                $destination = $targetPath . $new_file_name;

                if (move_uploaded_file($file['tmp_name'], $destination)) {
                    $urls[] = 'uploads/' . $targetSubDir . $new_file_name;
                } else {
                    echo json_encode(["success" => false, "message" => "파일 이동 실패: " . $file_name]);
                    exit();
                }
            } else {
                echo json_encode(["success" => false, "message" => "파일 업로드 오류: " . $file['error']]);
                exit();
            }
        } elseif ($fileType === 'image' && isset($_FILES['imageFiles'])) {
            $targetSubDir = 'images/';
            $targetPath = $uploadDir . $targetSubDir;
            if (!is_dir($targetPath)) {
                mkdir($targetPath, 0777, true);
            }

            foreach ($_FILES['imageFiles']['tmp_name'] as $key => $tmp_name) {
                if ($_FILES['imageFiles']['error'][$key] === UPLOAD_ERR_OK) {
                    $file_name = basename($_FILES['imageFiles']['name'][$key]);
                    $new_file_name = uniqid() . '_' . $file_name;
                    $destination = $targetPath . $new_file_name;

                    if (move_uploaded_file($tmp_name, $destination)) {
                        $urls[] = 'uploads/' . $targetSubDir . $new_file_name;
                    } else {
                        echo json_encode(["success" => false, "message" => "파일 이동 실패: " . $file_name]);
                        exit();
                    }
                } else {
                    echo json_encode(["success" => false, "message" => "파일 업로드 오류: " . $_FILES['imageFiles']['error'][$key]]);
                    exit();
                }
            }
        } else {
            echo json_encode(["success" => false, "message" => "유효하지 않은 파일 타입 또는 파일이 없습니다."]);
            exit();
        }
        echo json_encode(["success" => true, "message" => "파일 업로드 성공", "urls" => ($fileType === 'audio') ? $urls[0] : $urls]);
        break;

        case 'load':
            // 음원 목록 로드
            $musicList = [];
            $userId = $_SESSION['user_id'] ?? null;
            $userRole = $_SESSION['user_role'] ?? null;
    
            // 좋아요 수 기준으로 정렬하고 크리에이터 목록 필터링 기능 유지
            $sql = "
                SELECT
                    m.id,
                    m.name,
                    m.audioSrc,
                    m.uploaderId,
                    m.category,
                    COUNT(l.id) AS totalLikes
                FROM music m
                LEFT JOIN images i ON m.id = i.musicId
                LEFT JOIN likes l ON i.id = l.image_id
            ";
            $params = [];
            $types = "";
    
            // 크리에이터인 경우 자신이 업로드한 목록만 가져오도록 WHERE 절 추가
            if ($userRole === 'creator') {
                $sql .= " WHERE m.uploaderId = ?";
                $params[] = $userId;
                $types = "i";
            }
    
            // 카테고리 필터링 기능 추가
            if (isset($input['category']) && $input['category'] !== 'all') {
                $filterCategory = $conn->real_escape_string($input['category']);
                if ($userRole === 'creator') {
                    $sql .= " AND m.category = ?";
                } else {
                    $sql .= " WHERE m.category = ?";
                }
                $params[] = $filterCategory;
                $types .= "s";
            }
    
            $sql .= " GROUP BY m.id ORDER BY totalLikes DESC, m.created_at DESC";
            $stmt = $conn->prepare($sql);
            
            if (!empty($params)) {
                $stmt->bind_param($types, ...$params);
            }
    
            $stmt->execute();
            $result = $stmt->get_result();
    
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $images = [];
                    // In the 'load' case, update the image query to order by display_order:
                        $sql_images = "
                        SELECT i.id, i.imageSrc,
                            (SELECT COUNT(*) FROM likes WHERE image_id = i.id) AS likeCount,
                            (SELECT COUNT(*) FROM likes WHERE image_id = i.id AND user_id = ?) AS isLiked
                        FROM images i
                        WHERE i.musicId = ?
                        ORDER BY COALESCE(i.display_order, i.id) ASC
                    ";
                    $stmt_images = $conn->prepare($sql_images);
                    $stmt_images->bind_param("ii", $userId, $row['id']);
                    $stmt_images->execute();
                    $result_images = $stmt_images->get_result();
                    while ($img_row = $result_images->fetch_assoc()) {
                        $images[] = $img_row;
                    }
                    $stmt_images->close();
                    $row['images'] = $images;
                    $musicList[] = $row;
                }
            }
    
            // 고유한 카테고리 목록 가져오기
            $categories = [];
            $sql_categories = "SELECT DISTINCT category FROM music WHERE category IS NOT NULL AND category != '' ORDER BY category ASC";
            $result_categories = $conn->query($sql_categories);
            if ($result_categories) {
                while ($row = $result_categories->fetch_assoc()) {
                    $categories[] = $row['category'];
                }
            }
            
            echo json_encode(["success" => true, "musicList" => $musicList, "categories" => $categories]);
    
            $stmt->close();
            break;

        case 'addMusic':
            // 'creator' 역할 사용자만 음원 추가 가능
            if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || ($_SESSION['user_role'] ?? 'user') !== 'creator') {
                echo json_encode(["success" => false, "message" => "크리에이터만 음원을 추가할 수 있습니다."]);
                break;
            }
    
            $name = $conn->real_escape_string($input['name']);
            $audioSrc = $conn->real_escape_string($input['audioSrc']);
            $category = $conn->real_escape_string($input['category'] ?? ''); // 카테고리 정보 추가
            $images = $input['images'] ?? [];
            $uploaderId = $_SESSION['user_id']; // 세션에서 uploaderId 가져오기

        // 1. music 테이블에 음원 정보 삽입
        $stmt_music = $conn->prepare("INSERT INTO music (name, audioSrc, category, uploaderId) VALUES (?, ?, ?, ?)");
        if (!$stmt_music) {
            echo json_encode(["success" => false, "message" => "음원 추가 SQL 준비 실패: " . $conn->error]);
            break;
        }

        // **수정된 부분**: category 변수를 bind_param에 추가했습니다.
        $stmt_music->bind_param("sssi", $name, $audioSrc, $category, $uploaderId);
        if (!$stmt_music->execute()) {
            echo json_encode(["success" => false, "message" => "음원 추가 실패: " . $stmt_music->error]);
            $stmt_music->close();
            break;
        }
        $musicId = $conn->insert_id; // 새로 삽입된 음악의 ID
        $stmt_music->close();

        // 2. images 테이블에 관련 이미지 삽입
        if (!empty($images)) {
            // 💡 변경: display_order를 순차적으로 증가시킬 변수 초기화
            $display_order = 1; 

            $stmt_images = $conn->prepare("INSERT INTO images (musicId, imageSrc, display_order) VALUES (?, ?, ?)");
            if (!$stmt_images) {
                // 이미지 삽입 실패 시 음악은 유지되지만 오류 로깅
                error_log("이미지 추가 SQL 준비 실패 for musicId " . $musicId . ": " . $conn->error);
                echo json_encode(["success" => true, "message" => "음원 추가 성공 (이미지 일부 또는 전체 실패)"]);
                break;
            }

            foreach ($images as $imageSrc) {
                $imageSrc_esc = $conn->real_escape_string($imageSrc);
                // 💡 변경: 'is' (integer, string) 대신 'isi' (integer, string, integer)로 변경하고 $display_order 변수 추가
                $stmt_images->bind_param("isi", $musicId, $imageSrc_esc, $display_order); 
                
                if (!$stmt_images->execute()) {
                    error_log("이미지 삽입 실패 for musicId " . $musicId . ", imageSrc " . $imageSrc_esc . ": " . $stmt_images->error);
                }
                
                // 💡 변경: 다음 이미지의 순서를 위해 변수 값 증가
                $display_order++;
            }
            $stmt_images->close();
        }
        echo json_encode(["success" => true, "message" => "음원 추가 성공"]);
        break;

        case 'updateMusic':
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'creator') {
                echo json_encode(["success" => false, "message" => "크리에이터만 음원을 수정할 수 있습니다."]);
                break;
            }
    
            $updateData = $input['data'] ?? [];
            $musicId = $updateData['id'] ?? null;
            if (!$musicId) {
                echo json_encode(["success" => false, "message" => "음원 ID가 누락되었습니다."]);
                break;
            }
    
            $fields = [];
            $params = [];
            $types = "";
    
            if (isset($updateData['name'])) {
                $fields[] = "name = ?";
                $params[] = $updateData['name'];
                $types .= "s";
            }
    
            // 💡 수정된 부분: 카테고리 필드 처리 로직 추가
            if (isset($updateData['category'])) {
                $fields[] = "category = ?";
                $params[] = $updateData['category'];
                $types .= "s";
            }
    
            if (isset($updateData['audioSrc'])) {
                $fields[] = "audioSrc = ?";
                $params[] = $updateData['audioSrc'];
                $types .= "s";
            }
            
            $conn->begin_transaction();
    
            try {
                if (!empty($fields)) {
                    $sql = "UPDATE music SET " . implode(", ", $fields) . " WHERE id = ?";
                    $params[] = $musicId;
                    $types .= "i";
                    
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param($types, ...$params);
                    $stmt->execute();
                    $stmt->close();
                }
    
            // 새 이미지가 있을 경우 처리 (images 또는 newImages 모두 허용)
            $incomingImages = [];
            if (!empty($updateData['images'])) {
                $incomingImages = $updateData['images'];
            } elseif (!empty($updateData['newImages'])) {
                $incomingImages = $updateData['newImages'];
            }

            // ✅ 기존 이미지 삭제 X (Append 전략)
            // 기존에 사용하던 컬럼명이 musicId 인지 확인 (load/add/delete와 일치시켜야 함)

            if (!empty($incomingImages)) {
                // 방법 A) 중복 방지 SELECT 후 INSERT
                $checkStmt = $conn->prepare("SELECT 1 FROM images WHERE musicId = ? AND imageSrc = ?");
                $insStmt   = $conn->prepare("INSERT INTO images (musicId, imageSrc) VALUES (?, ?)");

                foreach ($incomingImages as $src) {
                    $checkStmt->bind_param("is", $musicId, $src);
                    $checkStmt->execute();
                    $checkStmt->store_result();
                    if ($checkStmt->num_rows === 0) {
                        $insStmt->bind_param("is", $musicId, $src);
                        $insStmt->execute();
                    }
                }
                $checkStmt->close();
                $insStmt->close();
            }

                $conn->commit();
                echo json_encode(["success" => true, "message" => "음원이 성공적으로 수정되었습니다."]);
            } catch (mysqli_sql_exception $e) {
                $conn->rollback();
                echo json_encode(["success" => false, "message" => "음원 수정 실패: " . $e->getMessage()]);
            }
            break;

    case 'deleteMusic':
        if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || ($_SESSION['user_role'] ?? 'user') !== 'creator') {
            echo json_encode(["success" => false, "message" => "크리에이터만 음원을 삭제할 수 있습니다."]);
            break;
        }

        $musicId = $input['musicId'];
        $uploaderId = $_SESSION['user_id'];

        // 1. 해당 음원에 연결된 이미지 경로들을 가져와서 실제 파일 삭제
        $sql_images = "SELECT imageSrc FROM images WHERE musicId = ?";
        $stmt_images = $conn->prepare($sql_images);
        $stmt_images->bind_param("i", $musicId);
        $stmt_images->execute();
        $result_images = $stmt_images->get_result();

        while ($row = $result_images->fetch_assoc()) {
            $filePath = __DIR__ . '/' . $row['imageSrc'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        }
        $stmt_images->close();

        // 2. 음원 파일 경로를 가져와서 실제 파일 삭제
        $sql_audio = "SELECT audioSrc FROM music WHERE id = ? AND uploaderId = ?";
        $stmt_audio = $conn->prepare($sql_audio);
        $stmt_audio->bind_param("ii", $musicId, $uploaderId);
        $stmt_audio->execute();
        $result_audio = $stmt_audio->get_result();
        $audio_row = $result_audio->fetch_assoc();

        if ($audio_row) {
            $filePath = __DIR__ . '/' . $audio_row['audioSrc'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        }
        $stmt_audio->close();

        // 3. 데이터베이스에서 좋아요, 이미지, 음원 정보 삭제 (CASCADE 설정이 되어 있지 않다면 필요)
        $conn->begin_transaction();
        try {
            $stmt_likes = $conn->prepare("DELETE FROM likes WHERE image_id IN (SELECT id FROM images WHERE musicId = ?)");
            $stmt_likes->bind_param("i", $musicId);
            $stmt_likes->execute();
            $stmt_likes->close();

            $stmt_images = $conn->prepare("DELETE FROM images WHERE musicId = ?");
            $stmt_images->bind_param("i", $musicId);
            $stmt_images->execute();
            $stmt_images->close();

            $stmt_music = $conn->prepare("DELETE FROM music WHERE id = ? AND uploaderId = ?");
            $stmt_music->bind_param("ii", $musicId, $uploaderId);
            $stmt_music->execute();
            $stmt_music->close();

            $conn->commit();
            echo json_encode(["success" => true, "message" => "음원과 관련 이미지가 성공적으로 삭제되었습니다."]);
        } catch (mysqli_sql_exception $exception) {
            $conn->rollback();
            echo json_encode(["success" => false, "message" => "삭제 실패: " . $exception->getMessage()]);
        }
        break;

    case 'deleteImage':
        if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || ($_SESSION['user_role'] ?? 'user') !== 'creator') {
            echo json_encode(["success" => false, "message" => "크리에이터만 이미지를 삭제할 수 있습니다."]);
            break;
        }
        $imageId = $input['imageId'];
        $uploaderId = $_SESSION['user_id'];

        // 1. 해당 이미지가 삭제 권한이 있는 사용자의 소유인지 확인하고 파일 경로 가져오기
        $sql_check = "
            SELECT i.imageSrc
            FROM images i
            JOIN music m ON i.musicId = m.id
            WHERE i.id = ? AND m.uploaderId = ?
        ";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bind_param("ii", $imageId, $uploaderId);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows === 0) {
            echo json_encode(["success" => false, "message" => "해당 이미지를 삭제할 권한이 없습니다."]);
            $stmt_check->close();
            break;
        }

        $imageSrc = $result_check->fetch_assoc()['imageSrc'];
        $stmt_check->close();

        // 2. 실제 파일 삭제
        $filePath = __DIR__ . '/' . $imageSrc;
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // 3. 데이터베이스에서 이미지 정보 삭제
        $stmt_delete = $conn->prepare("DELETE FROM images WHERE id = ?");
        $stmt_delete->bind_param("i", $imageId);
        if ($stmt_delete->execute()) {
            echo json_encode(["success" => true, "message" => "이미지가 성공적으로 삭제되었습니다."]);
        } else {
            echo json_encode(["success" => false, "message" => "이미지 삭제 실패: " . $stmt_delete->error]);
        }
        $stmt_delete->close();
        break;

    case 'toggleLike':
        $userId = $_SESSION['user_id'] ?? null;
        $imageId = $input['imageId'] ?? null;

        if (!$userId) {
            echo json_encode(["success" => false, "message" => "로그인해야 좋아요를 누를 수 있습니다."]);
            break;
        }
        if (!$imageId) {
            echo json_encode(["success" => false, "message" => "이미지 ID가 누락되었습니다."]);
            break;
        }

        // 이미 좋아요를 눌렀는지 확인
        $stmt_check = $conn->prepare("SELECT id FROM likes WHERE user_id = ? AND image_id = ?");
        $stmt_check->bind_param("ii", $userId, $imageId);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            // 이미 좋아요를 눌렀다면 취소
            $stmt_delete = $conn->prepare("DELETE FROM likes WHERE user_id = ? AND image_id = ?");
            $stmt_delete->bind_param("ii", $userId, $imageId);
            if ($stmt_delete->execute()) {
                echo json_encode(["success" => true, "message" => "좋아요가 취소되었습니다."]);
            } else {
                echo json_encode(["success" => false, "message" => "좋아요 취소 실패: " . $stmt_delete->error]);
            }
            $stmt_delete->close();
        } else {
            // 좋아요를 누르지 않았다면 추가
            $stmt_insert = $conn->prepare("INSERT INTO likes (user_id, image_id) VALUES (?, ?)");
            $stmt_insert->bind_param("ii", $userId, $imageId);
            if ($stmt_insert->execute()) {
                echo json_encode(["success" => true, "message" => "좋아요를 눌렀습니다."]);
            } else {
                echo json_encode(["success" => false, "message" => "좋아요 추가 실패: " . $stmt_insert->error]);
            }
            $stmt_insert->close();
        }
        $stmt_check->close();
        break;

    case 'getLikedImages':
        // 현재 사용자가 좋아요를 누른 이미지 목록 가져오기
        $userId = $_SESSION['user_id'] ?? null;

        if (!$userId) {
            echo json_encode(["success" => false, "message" => "로그인해야 좋아요 목록을 볼 수 있습니다."]);
            break;
        }

        $likedImages = [];
        $sql = "
            SELECT
                i.id,
                i.imageSrc,
                i.musicId,
                m.name AS musicName,
                m.audioSrc AS audioSrc,
                (SELECT COUNT(*) FROM likes WHERE image_id = i.id) AS likeCount
            FROM images i
            JOIN likes l ON i.id = l.image_id
            JOIN music m ON i.musicId = m.id
            WHERE l.user_id = ?
            ORDER BY l.created_at DESC
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $likedImages[] = $row;
            }
            echo json_encode(["success" => true, "likedImages" => $likedImages]);
        } else {
            echo json_encode(["success" => false, "message" => "아직 좋아요를 누른 음악이 없습니다."]);
        }
        $stmt->close();
        break;

    // 🚀 댓글 기능 추가된 부분
    case 'submitComment':
        $userId = $_SESSION['user_id'] ?? null;
        $musicId = $input['musicId'] ?? null;
        $content = $input['content'] ?? null;

        if (!$userId || !$musicId || !$content) {
            echo json_encode(["success" => false, "message" => "로그인 후 댓글을 작성해주세요."]);
            break;
        }

        $stmt = $conn->prepare("INSERT INTO comments (musicId, user_id, content) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $musicId, $userId, $content);

        if ($stmt->execute()) {
            echo json_encode(["success" => true, "message" => "댓글이 성공적으로 등록되었습니다."]);
        } else {
            echo json_encode(["success" => false, "message" => "댓글 등록 실패: " . $stmt->error]);
        }
        $stmt->close();
        break;

    case 'getComments':
        $musicId = $input['musicId'] ?? null;

        if (!$musicId) {
            echo json_encode(["success" => false, "message" => "음악 ID가 누락되었습니다."]);
            break;
        }

        $sql = "SELECT c.*, u.name, u.email, u.picture FROM comments c JOIN users u ON c.user_id = u.id WHERE c.musicId = ? ORDER BY c.created_at DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $musicId);
        $stmt->execute();
        $result = $stmt->get_result();

        $comments = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $comments[] = $row;
            }
        }
        echo json_encode(["success" => true, "comments" => $comments]);
        $stmt->close();
        break;

        case 'reorderImage':
            // Check user authentication and role
            if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || ($_SESSION['user_role'] ?? 'user') !== 'creator') {
                echo json_encode(["success" => false, "message" => "크리에이터만 이미지 순서를 변경할 수 있습니다."]);
                break;
            }
        
            $imageId = $input['imageId'] ?? null;
            $direction = $input['direction'] ?? null;
            $uploaderId = $_SESSION['user_id'];
        
            if (!$imageId || !$direction) {
                echo json_encode(["success" => false, "message" => "이미지 ID와 방향 정보가 필요합니다."]);
                break;
            }
        
            $conn->begin_transaction();
            try {
                // 현재 이미지 정보와 순서를 가져오고, 해당 음악이 현재 사용자 소유인지 확인
                $stmt = $conn->prepare("
                    SELECT i.id, i.musicId, i.display_order 
                    FROM images i 
                    JOIN music m ON i.musicId = m.id 
                    WHERE i.id = ? AND m.uploaderId = ?
                ");
                $stmt->bind_param("ii", $imageId, $uploaderId);
                $stmt->execute();
                $result = $stmt->get_result();
                $currentImage = $result->fetch_assoc();
                $stmt->close();
        
                if (!$currentImage) {
                    throw new Exception("이미지를 찾을 수 없거나 권한이 없습니다.");
                }
        
                $currentMusicId = $currentImage['musicId'];
        
                // display_order가 NULL이거나 0인 경우, 해당 음악의 모든 이미지에 순서를 할당
                if ($currentImage['display_order'] === null || $currentImage['display_order'] == 0) {
                    $stmt = $conn->prepare("SELECT id FROM images WHERE musicId = ? ORDER BY id ASC");
                    $stmt->bind_param("i", $currentMusicId);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    $order = 1;
                    $stmt_update = $conn->prepare("UPDATE images SET display_order = ? WHERE id = ?");
                    while ($row = $result->fetch_assoc()) {
                        $stmt_update->bind_param("ii", $order, $row['id']);
                        $stmt_update->execute();
                        $order++;
                    }
                    $stmt_update->close();
                    $stmt->close();
                    
                    // 현재 이미지의 순서를 다시 가져오기
                    $stmt = $conn->prepare("SELECT display_order FROM images WHERE id = ?");
                    $stmt->bind_param("i", $imageId);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $currentImage['display_order'] = $result->fetch_assoc()['display_order'];
                    $stmt->close();
                }
        
                $currentOrder = $currentImage['display_order'];
                $targetOrder = $direction === 'up' ? $currentOrder - 1 : $currentOrder + 1;
                
                // 이동할 대상 이미지가 있는지 확인
                $stmt = $conn->prepare("SELECT id FROM images WHERE musicId = ? AND display_order = ?");
                $stmt->bind_param("ii", $currentMusicId, $targetOrder);
                $stmt->execute();
                $result = $stmt->get_result();
                $targetImage = $result->fetch_assoc();
                $stmt->close();
        
                if (!$targetImage) {
                    $conn->rollback();
                    $limitMessage = $direction === 'up' ? "첫 번째 위치입니다." : "마지막 위치입니다.";
                    echo json_encode(["success" => false, "message" => $limitMessage]);
                    break;
                }
                
                // 두 이미지의 display_order 값을 교환
                $stmt = $conn->prepare("
                    UPDATE images
                    SET display_order = CASE
                        WHEN id = ? THEN ?
                        WHEN id = ? THEN ?
                    END
                    WHERE id IN (?, ?)
                ");
                $stmt->bind_param("iiiiii", 
                    $currentImage['id'], $targetOrder, 
                    $targetImage['id'], $currentOrder,
                    $currentImage['id'], $targetImage['id']
                );
                $stmt->execute();
                $stmt->close();
        
                $conn->commit();
                echo json_encode(["success" => true, "message" => "이미지 순서가 성공적으로 변경되었습니다."]);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(["success" => false, "message" => "이미지 순서 변경 실패: " . $e->getMessage()]);
            }
            break;

    default:
        echo json_encode(["success" => false, "message" => "알 수 없는 요청입니다."]);
        break;
}

$conn->close();

?>