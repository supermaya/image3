# 포인트 시스템 설정 가이드

## 개요
기존 프리미엄 카테고리 기반 과금 구조를 포인트 시스템으로 변경했습니다.

## 포인트 시스템 구조

### 1. 기본 포인트
- **신규 가입 시**: 500P 지급 (1회성, 1년 후 소멸)
- **매일 접속 보너스**: 매일 접속 시 60P 자동 지급
- **지급된 포인트 소멸**: 자정에 자동 소멸

### 2. 포인트 차감
- **갤러리 진입 시**: 17P 차감
- **우선순위**: 오늘 지급 포인트 → 부족 시 유상 충전 포인트(wallet)에서 차감

### 3. 데이터베이스 테이블
- `users`: 사용자 정보 + `signup_points_given` 컬럼 추가
- `point_wallet`: 유상 충전 포인트 지갑
- `transactions`: 충전/차감 내역
- `user_daily_points`: 일일 포인트 적립/사용/소멸 기록

## 설치 및 설정

### 1. 데이터베이스 설정
```bash
mysql -u your_username -p your_database < db_setup.sql
```

### 2. Cron Job 설정 (일일 포인트 소멸)
```bash
# crontab 편집
crontab -e

# 매일 자정에 포인트 소멸 처리 실행
0 0 * * * /usr/bin/php /path/to/your/project/expire_points_cron.php
```

### 3. 로그 디렉토리 생성
```bash
mkdir logs
chmod 755 logs
```

## API 엔드포인트

### 포인트 관련 API
- `daily_bonus`: 출석 보너스 지급
- `use_point`: 갤러리 이용료 차감
- `get_points`: 포인트 현황 조회
- `expire_points`: 포인트 소멸 처리 (cron용)

### 사용 예시
```javascript
// 출석 보너스 받기
fetch('api.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'daily_bonus' })
});

// 포인트 현황 조회
fetch('api.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'get_points' })
});
```

## 프론트엔드 UI

### 포인트 표시 영역
- **⚡ 일일 포인트**: 오늘 받은 포인트 (자정 소멸)
- **💎 지갑 포인트**: 유상 충전 포인트 (영구 보존)
- **🎯 총 포인트**: 사용 가능한 전체 포인트
- **출석체크 버튼**: 일일 보너스 수령

### 기능
- 로그인 시 자동으로 포인트 정보 로드
- 갤러리 진입 시 자동 포인트 차감
- 출석체크 버튼을 통한 일일 보너스 수령
- 실시간 포인트 업데이트

## 주요 변경사항

### 기존 시스템과의 차이점
1. **프리미엄 구독** → **포인트 기반 과금**
2. **월 구독료** → **갤러리당 17P 차감**
3. **무제한 이용** → **포인트 소진 시 이용 제한**

### 비회원 처리
- 비회원은 포인트 차감 없이 갤러리 이용 가능
- 로그인 유도를 위해 일부 기능 제한

## 모니터링

### 로그 확인
```bash
# 포인트 소멸 로그 확인
tail -f logs/point_expiration.log

# 에러 로그 확인 (웹서버 로그)
tail -f /var/log/apache2/error.log
```

### 데이터베이스 모니터링
```sql
-- 일일 포인트 현황
SELECT
    DATE(created_at) as date,
    COUNT(*) as users,
    SUM(daily_points_earned) as total_earned,
    SUM(daily_points_used) as total_used,
    SUM(daily_points_expired) as total_expired
FROM user_daily_points
GROUP BY DATE(created_at)
ORDER BY date DESC LIMIT 7;

-- 포인트 트랜잭션 현황
SELECT
    type,
    COUNT(*) as count,
    SUM(amount) as total_amount
FROM transactions
WHERE DATE(created_at) = CURDATE()
GROUP BY type;
```

## 문제 해결

### 일반적인 문제
1. **포인트가 표시되지 않음**: 브라우저 캐시 삭제 후 재로그인
2. **출석체크가 안됨**: 이미 오늘 받았는지 확인
3. **갤러리가 안열림**: 포인트 부족 여부 확인

### 개발자 디버깅
- 브라우저 개발자 도구 Console 탭에서 에러 확인
- Network 탭에서 API 응답 확인
- PHP 에러 로그 확인

## 보안 고려사항
- 포인트 조작 방지를 위한 서버사이드 검증
- SQL 인젝션 방지를 위한 Prepared Statement 사용
- 트랜잭션을 통한 데이터 일관성 보장