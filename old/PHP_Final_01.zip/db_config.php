<?php
$servername = "localhost"; // 일반적으로 localhost
$username = "playelga_suno_user01";
$password = "suno_user01";
$dbname = "playelga_musicandimage";

// DB 연결
$conn = new mysqli($servername, $username, $password, $dbname);

// 연결 오류 확인
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>